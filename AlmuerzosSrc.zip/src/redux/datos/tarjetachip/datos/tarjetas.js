export const tarjetas = [{
        id: 1,
        titulo: "Visa debito",
        telefono: "11",
        url: "http://www.zul.com.ar/bugs/image/tarjetas/t-visa-debito.png",
        codigo: "VVI"
    },
    {
        id: 2,
        titulo: "Visa credito",
        telefono: "11",
        url: "http://www.zul.com.ar/bugs/image/tarjetas/t-visa-credito.png",
        codigo: "0VI"
    },
    {
        id: 3,
        titulo: "Master debito",
        telefono: "11",
        url: "http://www.zul.com.ar/bugs/image/tarjetas/t-master-debito.png",
        codigo: "VVI"
    },
    {
        id: 4,
        titulo: "Master credito",
        telefono: "11",
        url: "http://www.zul.com.ar/bugs/image/tarjetas/t-master-credito.png",
        codigo: "VVI"
    },
    {
        id: 5,
        titulo: "Diners credito",
        telefono: "11",
        url: "http://www.zul.com.ar/bugs/image/tarjetas/t-diners-credito.png",
        codigo: "VVI"
    },
    {
        id: 6,
        titulo: "Amex credito",
        telefono: "11",
        url: "http://www.zul.com.ar/bugs/image/tarjetas/t-amex-credito.png",
        codigo: "VVI"
    },
    {
        id: 7,
        titulo: "Naranja credito",
        telefono: "11",
        url: "http://www.zul.com.ar/bugs/image/tarjetas/t-naranja-credito.png",
        codigo: "VVI"
    }
]