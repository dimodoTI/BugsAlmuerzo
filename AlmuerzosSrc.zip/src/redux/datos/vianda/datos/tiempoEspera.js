export const tiempos = {
    viandatarjetachiplectura: { segundos: 20 },
    viandaselecciontipomenu: { segundos: 25 },
    viandaseleccionmenu: { segundos: 30 },
    viandamenuaceptacion: { segundos: 35 },
    viandamenuexito: { segundos: 5 }
}