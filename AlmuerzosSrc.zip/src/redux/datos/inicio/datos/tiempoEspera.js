export const tiempos = {
    mensajeespera: { segundos: 10 },
    error: { segundos: 3 }
}