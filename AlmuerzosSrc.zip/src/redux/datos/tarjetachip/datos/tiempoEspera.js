export const tiempos = {
    tarjetachiplectura: {
        segundos: 20
    },
    tarjetachipseleccionimporte: {
        segundos: 25
    },
    tarjetachipselecciontarjetacredito: {
        segundos: 30
    },
    cargatarjetacreditoposnet: {
        segundos: 50
    },
    tarjetachiprecargaexito: {
        segundos: 5
    }
}